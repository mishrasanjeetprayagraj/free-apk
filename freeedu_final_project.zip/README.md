# FreeEdu - Android App

This is the Free Education Android app project.

## 🚀 How to Get Your APK

1. Create a new GitHub repository.
2. Upload this project (all files, including the `.github/workflows/` folder).
3. Push to the `main` branch.
4. Go to the **Actions tab** → wait for the workflow to finish.
5. Check the **Releases** section → download `app-debug.apk`.
   - Permanent link: `https://github.com/<your-username>/<your-repo>/releases/tag/nightly`

The APK will update automatically every time you push new changes.
